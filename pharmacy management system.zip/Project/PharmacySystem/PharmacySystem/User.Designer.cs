﻿namespace PharmacySystem
{
    partial class User
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(User));
            this.userMainPanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dashBoard = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.adminBoard = new System.Windows.Forms.Button();
            this.billing = new System.Windows.Forms.Button();
            this.addCustomer = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // userMainPanel
            // 
            this.userMainPanel.BackColor = System.Drawing.Color.Gray;
            this.userMainPanel.Location = new System.Drawing.Point(351, 74);
            this.userMainPanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.userMainPanel.Name = "userMainPanel";
            this.userMainPanel.Size = new System.Drawing.Size(1249, 887);
            this.userMainPanel.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.dashBoard);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.adminBoard);
            this.panel1.Controls.Add(this.billing);
            this.panel1.Controls.Add(this.addCustomer);
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(0, 74);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(353, 887);
            this.panel1.TabIndex = 3;
            // 
            // dashBoard
            // 
            this.dashBoard.BackColor = System.Drawing.Color.Navy;
            this.dashBoard.FlatAppearance.BorderSize = 0;
            this.dashBoard.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.dashBoard.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.dashBoard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.dashBoard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dashBoard.Font = new System.Drawing.Font("Perpetua Titling MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashBoard.ForeColor = System.Drawing.Color.Transparent;
            this.dashBoard.Location = new System.Drawing.Point(0, 322);
            this.dashBoard.Margin = new System.Windows.Forms.Padding(4);
            this.dashBoard.Name = "dashBoard";
            this.dashBoard.Size = new System.Drawing.Size(349, 68);
            this.dashBoard.TabIndex = 7;
            this.dashBoard.Text = "Dashboard";
            this.dashBoard.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(44, 17);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(265, 286);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // adminBoard
            // 
            this.adminBoard.BackColor = System.Drawing.Color.Navy;
            this.adminBoard.FlatAppearance.BorderSize = 0;
            this.adminBoard.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.adminBoard.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.adminBoard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.adminBoard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.adminBoard.Font = new System.Drawing.Font("Perpetua Titling MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminBoard.ForeColor = System.Drawing.Color.Transparent;
            this.adminBoard.Location = new System.Drawing.Point(0, 638);
            this.adminBoard.Margin = new System.Windows.Forms.Padding(4);
            this.adminBoard.Name = "adminBoard";
            this.adminBoard.Size = new System.Drawing.Size(349, 68);
            this.adminBoard.TabIndex = 2;
            this.adminBoard.Text = "Admin";
            this.adminBoard.UseVisualStyleBackColor = false;
            this.adminBoard.Click += new System.EventHandler(this.adminBoard_Click);
            // 
            // billing
            // 
            this.billing.BackColor = System.Drawing.Color.Navy;
            this.billing.FlatAppearance.BorderSize = 0;
            this.billing.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.billing.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.billing.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.billing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.billing.Font = new System.Drawing.Font("Perpetua Titling MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.billing.ForeColor = System.Drawing.Color.Transparent;
            this.billing.Location = new System.Drawing.Point(4, 475);
            this.billing.Margin = new System.Windows.Forms.Padding(4);
            this.billing.Name = "billing";
            this.billing.Size = new System.Drawing.Size(349, 68);
            this.billing.TabIndex = 1;
            this.billing.Text = "Billing";
            this.billing.UseVisualStyleBackColor = false;
            // 
            // addCustomer
            // 
            this.addCustomer.BackColor = System.Drawing.Color.Navy;
            this.addCustomer.FlatAppearance.BorderSize = 0;
            this.addCustomer.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.addCustomer.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.addCustomer.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.addCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addCustomer.Font = new System.Drawing.Font("Perpetua Titling MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addCustomer.ForeColor = System.Drawing.Color.Transparent;
            this.addCustomer.Location = new System.Drawing.Point(0, 399);
            this.addCustomer.Margin = new System.Windows.Forms.Padding(4);
            this.addCustomer.Name = "addCustomer";
            this.addCustomer.Size = new System.Drawing.Size(349, 68);
            this.addCustomer.TabIndex = 0;
            this.addCustomer.Text = "Add Customer";
            this.addCustomer.UseVisualStyleBackColor = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.Black;
            this.flowLayoutPanel1.Controls.Add(this.pictureBox2);
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(1, -1);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1600, 75);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1531, 4);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(65, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // User
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1600, 960);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.userMainPanel);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "User";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pharmacist";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel userMainPanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button adminBoard;
        private System.Windows.Forms.Button billing;
        private System.Windows.Forms.Button addCustomer;
        private System.Windows.Forms.Button dashBoard;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}