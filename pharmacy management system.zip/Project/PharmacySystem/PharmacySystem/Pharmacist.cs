﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;

namespace PharmacySystem
{
    public  partial class Pharmacist : Form
    {

        private Panel p;
        
        public Pharmacist(Panel p)
        {
            InitializeComponent();
            this.p = p;
         
        }
        public void cheakValue()
        {
            if (string.IsNullOrEmpty(name.Text))
            {
                name.ForeColor = System.Drawing.Color.Red;
                name.Font = new Font(name.Font.FontFamily,8);
                name.Text = "You must enter name";
                //name.ForeColor = System.Drawing.Color.Black;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //cheakValue();
            try
            {
                String NAME = name.Text;
                
                String GENDER = gender.GetItemText(gender.SelectedItem);

                int MOBILE = Convert.ToInt32(mobile.Text);
                String DOB = dob.Text;
                String ADDRESS = address.Text;
                String EMAIL = email.Text;
                String PASSWORD = password.Text;
                String NIC = nic.Text;
               // cheakValue();
                String q = " INSERT INTO Pharamcist(Name, Gender,Nic,Mobile,Dob, Address, Email,Password) VALUES('" + NAME + "','" + GENDER + "','"+NIC+"','" + MOBILE + "','" + DOB + "','" + ADDRESS + "','" + EMAIL + "','" + PASSWORD + "')";
                ConnectDb.setData(q, "Sucessfully Added Pharmacist.!");

            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
            


           
        }

        private void backBt_Click(object sender, EventArgs e)
        {
            PanalLoad.loadForm(new DashBoard(),p);
        }

        private void update_Click(object sender, EventArgs e)
        {

            //cheakValue();
            try
            {
                String NAME = name.Text;

                String GENDER = gender.GetItemText(gender.SelectedItem);

                int MOBILE = Convert.ToInt32(mobile.Text);
                String DOB = dob.Text;
                String ADDRESS = address.Text;
                String EMAIL = email.Text;
                String PASSWORD = password.Text;
                String NIC = nic.Text;
                // cheakValue();
                String q = " Update Pharamcist SET(Name, Gender,Nic,Mobile,Dob, Address, Email,Password) VALUES('" + NAME + "','" + GENDER + "','" + NIC + "','" + MOBILE + "','" + DOB + "','" + ADDRESS + "','" + EMAIL + "','" + PASSWORD + "') WHERE Id=1";
                ConnectDb.setData(q, "Sucessfully Updated Pharmacist.!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
