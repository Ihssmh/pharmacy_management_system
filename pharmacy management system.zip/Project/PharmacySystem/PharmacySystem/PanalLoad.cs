﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PharmacySystem
{
   public static class PanalLoad
    {
    
       
         public static  void loadForm(object Form,Panel p)  //load many forms using one panal
        {
            if (p.Controls.Count >= 0)
            {
                p.Controls.Clear();
                Form f = Form as Form;
                f.TopLevel = false;
                

                p.Controls.Add(f);
                p.Tag = f;
                f.Size = p.Size;
                //  f.Anchor= AnchorStyles.Left|AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right;
                f.Dock = DockStyle.Fill;
                f.Show();
            }

        }
    }
}
