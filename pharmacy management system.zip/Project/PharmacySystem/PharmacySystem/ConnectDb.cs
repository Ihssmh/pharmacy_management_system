﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SQLite; //use sqllite 
using System.Windows.Forms;
using System.Data;


namespace PharmacySystem
{
   public static class ConnectDb
    {
        public static SQLiteConnection getConnection()
        {
           
           
            SQLiteConnection con=null;
            con = new SQLiteConnection();
            con.ConnectionString = @"Data Source=C:\Users\University_Works\Desktop\Project\PP.db";
            
            return con;
        }

        public static DataSet getData(string query)
        {
            SQLiteConnection con;
            DataSet ds = null; 

            try
            {
                con= getConnection();
              
                SQLiteDataAdapter da = new SQLiteDataAdapter(query, con);
                ds = new DataSet();
                da.Fill(ds);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

           

            return ds;
        }

        public static void setData(string query,String msg)
        {
            SQLiteConnection con = getConnection();
            SQLiteCommand cmd = new SQLiteCommand(query,con);
            //cmd.Connection = con;
            //cmd.CommandText = query;
            try
            {
                con.Open();
                cmd.CommandText = query;
                cmd.ExecuteNonQuery();
                MessageBox.Show(msg, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally {
              
                con.Close();
            }
          
           

            

           
        }


    }

    
}
