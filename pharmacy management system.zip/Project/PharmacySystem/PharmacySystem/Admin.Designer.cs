﻿namespace PharmacySystem
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.panel1 = new System.Windows.Forms.Panel();
            this.goDashboard = new System.Windows.Forms.PictureBox();
            this.settings = new System.Windows.Forms.Button();
            this.customers = new System.Windows.Forms.Button();
            this.salesReport = new System.Windows.Forms.Button();
            this.medicine = new System.Windows.Forms.Button();
            this.supplier = new System.Windows.Forms.Button();
            this.pharmacist = new System.Windows.Forms.Button();
            this.close = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.maximizedBtn = new System.Windows.Forms.PictureBox();
            this.adminMainPanal = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.goDashboard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.close)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maximizedBtn)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Controls.Add(this.goDashboard);
            this.panel1.Controls.Add(this.settings);
            this.panel1.Controls.Add(this.customers);
            this.panel1.Controls.Add(this.salesReport);
            this.panel1.Controls.Add(this.medicine);
            this.panel1.Controls.Add(this.supplier);
            this.panel1.Controls.Add(this.pharmacist);
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(0, 133);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(353, 969);
            this.panel1.TabIndex = 0;
            // 
            // goDashboard
            // 
            this.goDashboard.Image = ((System.Drawing.Image)(resources.GetObject("goDashboard.Image")));
            this.goDashboard.Location = new System.Drawing.Point(44, 17);
            this.goDashboard.Margin = new System.Windows.Forms.Padding(4);
            this.goDashboard.Name = "goDashboard";
            this.goDashboard.Size = new System.Drawing.Size(265, 286);
            this.goDashboard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.goDashboard.TabIndex = 6;
            this.goDashboard.TabStop = false;
            this.goDashboard.Click += new System.EventHandler(this.goDashboard_Click);
            // 
            // settings
            // 
            this.settings.BackColor = System.Drawing.Color.Navy;
            this.settings.FlatAppearance.BorderSize = 0;
            this.settings.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.settings.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.settings.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.settings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.settings.Font = new System.Drawing.Font("Perpetua Titling MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settings.ForeColor = System.Drawing.Color.Transparent;
            this.settings.Location = new System.Drawing.Point(0, 656);
            this.settings.Margin = new System.Windows.Forms.Padding(4);
            this.settings.Name = "settings";
            this.settings.Size = new System.Drawing.Size(349, 68);
            this.settings.TabIndex = 5;
            this.settings.Text = "Settings";
            this.settings.UseVisualStyleBackColor = false;
            this.settings.Click += new System.EventHandler(this.settings_Click);
            // 
            // customers
            // 
            this.customers.BackColor = System.Drawing.Color.Navy;
            this.customers.FlatAppearance.BorderSize = 0;
            this.customers.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.customers.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.customers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.customers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.customers.Font = new System.Drawing.Font("Perpetua Titling MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customers.ForeColor = System.Drawing.Color.Transparent;
            this.customers.Location = new System.Drawing.Point(0, 588);
            this.customers.Margin = new System.Windows.Forms.Padding(4);
            this.customers.Name = "customers";
            this.customers.Size = new System.Drawing.Size(349, 68);
            this.customers.TabIndex = 4;
            this.customers.Text = "Customers";
            this.customers.UseVisualStyleBackColor = false;
            this.customers.Click += new System.EventHandler(this.customers_Click);
            // 
            // salesReport
            // 
            this.salesReport.BackColor = System.Drawing.Color.Navy;
            this.salesReport.FlatAppearance.BorderSize = 0;
            this.salesReport.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.salesReport.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.salesReport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.salesReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.salesReport.Font = new System.Drawing.Font("Perpetua Titling MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salesReport.ForeColor = System.Drawing.Color.Transparent;
            this.salesReport.Location = new System.Drawing.Point(0, 521);
            this.salesReport.Margin = new System.Windows.Forms.Padding(4);
            this.salesReport.Name = "salesReport";
            this.salesReport.Size = new System.Drawing.Size(349, 68);
            this.salesReport.TabIndex = 3;
            this.salesReport.Text = "Sales Report";
            this.salesReport.UseVisualStyleBackColor = false;
            this.salesReport.Click += new System.EventHandler(this.salesReport_Click);
            // 
            // medicine
            // 
            this.medicine.BackColor = System.Drawing.Color.Navy;
            this.medicine.FlatAppearance.BorderSize = 0;
            this.medicine.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.medicine.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.medicine.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.medicine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.medicine.Font = new System.Drawing.Font("Perpetua Titling MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.medicine.ForeColor = System.Drawing.Color.Transparent;
            this.medicine.Location = new System.Drawing.Point(0, 453);
            this.medicine.Margin = new System.Windows.Forms.Padding(4);
            this.medicine.Name = "medicine";
            this.medicine.Size = new System.Drawing.Size(349, 68);
            this.medicine.TabIndex = 2;
            this.medicine.Text = "Medicine";
            this.medicine.UseVisualStyleBackColor = false;
            this.medicine.Click += new System.EventHandler(this.medicine_Click);
            // 
            // supplier
            // 
            this.supplier.BackColor = System.Drawing.Color.Navy;
            this.supplier.FlatAppearance.BorderSize = 0;
            this.supplier.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.supplier.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.supplier.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.supplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.supplier.Font = new System.Drawing.Font("Perpetua Titling MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.supplier.ForeColor = System.Drawing.Color.Transparent;
            this.supplier.Location = new System.Drawing.Point(0, 386);
            this.supplier.Margin = new System.Windows.Forms.Padding(4);
            this.supplier.Name = "supplier";
            this.supplier.Size = new System.Drawing.Size(349, 68);
            this.supplier.TabIndex = 1;
            this.supplier.Text = "Supplier";
            this.supplier.UseVisualStyleBackColor = false;
            this.supplier.Click += new System.EventHandler(this.supplier_Click);
            // 
            // pharmacist
            // 
            this.pharmacist.BackColor = System.Drawing.Color.Navy;
            this.pharmacist.FlatAppearance.BorderSize = 0;
            this.pharmacist.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.pharmacist.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.pharmacist.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.pharmacist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pharmacist.Font = new System.Drawing.Font("Perpetua Titling MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pharmacist.ForeColor = System.Drawing.Color.Transparent;
            this.pharmacist.Location = new System.Drawing.Point(0, 320);
            this.pharmacist.Margin = new System.Windows.Forms.Padding(4);
            this.pharmacist.Name = "pharmacist";
            this.pharmacist.Size = new System.Drawing.Size(349, 68);
            this.pharmacist.TabIndex = 0;
            this.pharmacist.Text = "Pharmacist";
            this.pharmacist.UseVisualStyleBackColor = false;
            this.pharmacist.Click += new System.EventHandler(this.pharmacist_Click);
            // 
            // close
            // 
            this.close.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.close.Image = ((System.Drawing.Image)(resources.GetObject("close.Image")));
            this.close.Location = new System.Drawing.Point(1475, 36);
            this.close.Margin = new System.Windows.Forms.Padding(4);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(65, 62);
            this.close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.close.TabIndex = 0;
            this.close.TabStop = false;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(544, 52);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(409, 46);
            this.label1.TabIndex = 3;
            this.label1.Text = "The New Pharamcy";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.maximizedBtn);
            this.panel2.Controls.Add(this.close);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1554, 129);
            this.panel2.TabIndex = 3;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // maximizedBtn
            // 
            this.maximizedBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.maximizedBtn.Image = ((System.Drawing.Image)(resources.GetObject("maximizedBtn.Image")));
            this.maximizedBtn.Location = new System.Drawing.Point(1401, 45);
            this.maximizedBtn.Name = "maximizedBtn";
            this.maximizedBtn.Size = new System.Drawing.Size(52, 53);
            this.maximizedBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.maximizedBtn.TabIndex = 0;
            this.maximizedBtn.TabStop = false;
            this.maximizedBtn.Click += new System.EventHandler(this.maximizedBtn_Click);
            // 
            // adminMainPanal
            // 
            this.adminMainPanal.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.adminMainPanal.BackColor = System.Drawing.Color.Gray;
            this.adminMainPanal.Location = new System.Drawing.Point(353, 135);
            this.adminMainPanal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.adminMainPanal.Name = "adminMainPanal";
            this.adminMainPanal.Size = new System.Drawing.Size(1198, 965);
            this.adminMainPanal.TabIndex = 2;
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1553, 1102);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.adminMainPanal);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.goDashboard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.close)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maximizedBtn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button pharmacist;
        private System.Windows.Forms.Button customers;
        private System.Windows.Forms.Button salesReport;
        private System.Windows.Forms.Button medicine;
        private System.Windows.Forms.Button supplier;
        private System.Windows.Forms.PictureBox goDashboard;
        private System.Windows.Forms.Button settings;
        private System.Windows.Forms.PictureBox close;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel adminMainPanal;
        private System.Windows.Forms.PictureBox maximizedBtn;
    }
}

