﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PharmacySystem
{
    public partial class User : Form
    {
        public User()
        {
            InitializeComponent();
        }

        public void loadForm(object Form)  //load many forms using one panal
        {
            if (this.userMainPanel.Controls.Count >= 0)
            {
                this.userMainPanel.Controls.Clear();
                Form f = Form as Form;
                f.TopLevel = false;
                f.Dock = DockStyle.Fill;
                this.userMainPanel.Controls.Add(f);
                this.userMainPanel.Tag = f;
                f.Show();
            }

        }

        private void adminBoard_Click(object sender, EventArgs e)
        {
            this.Close();
            Admin a=new Admin();
            Application.Run(a);
            
        }
    }
}
