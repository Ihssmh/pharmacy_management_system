﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace PharmacySystem
{
    public partial class Admin : Form
    {
        private DashBoard obj;


        public Admin()
        {
            InitializeComponent();
            

            obj = new DashBoard();
            PanalLoad.loadForm(obj,adminMainPanal);

        }  
            
       

        private void pharmacist_Click(object sender, EventArgs e)
        {
            Pharmacist obj = new Pharmacist(adminMainPanal);
            PanalLoad.loadForm(obj,adminMainPanal);
        }

        private void supplier_Click(object sender, EventArgs e)
        {
            Supplier obj = new Supplier();
            PanalLoad.loadForm(obj, adminMainPanal);
        }

        private void medicine_Click(object sender, EventArgs e)
        {
           Medicine obj=new Medicine();
            PanalLoad.loadForm(obj, adminMainPanal);
        }

        private void salesReport_Click(object sender, EventArgs e)
        {
            SalesReport sr1 = new SalesReport();
            PanalLoad.loadForm(sr1, adminMainPanal);
        }

        private void customers_Click(object sender, EventArgs e)
        {
            Customers c1 = new Customers();
            PanalLoad.loadForm(c1, adminMainPanal);
        }

        private void settings_Click(object sender, EventArgs e)
        {
            Settings ss1 = new Settings();
            PanalLoad.loadForm(ss1, adminMainPanal);
        }

        private void close_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to close.?","Waring",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)==DialogResult.Yes)
            {
                Application.Exit();
            }
        }

       

        private void goDashboard_Click(object sender, EventArgs e)
        {
            PanalLoad.loadForm(obj,adminMainPanal);
        }

        private void maximizedBtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
